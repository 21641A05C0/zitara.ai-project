data = {
	'User_1': { 
		'rayban_wayfarer_havane_vert': 2.7,
        'carrera_114S_blue_gray': 4.72,
        'mykita_black': 1.34,
        'polaroid_6016_blue_grey': 4.17,
	},

	'User_2': { 
        'rayban_wayfarer_havane_vert': 3.12,
        'carrera_114S_blue_gray': 3.78,
        'latch_havana_green': 4.55,
        'aliexpress_steampunk_gold_blue_mirror': 4.44,
        'mykita_black': 2.33,
        'polaroid_6016_blue_grey': 4.55,
	},

	'User_3': { 
        'rayban_wayfarer_havane_vert': 2.45, 
        'latch_havana_green': 4.56,
        'mykita_black': 4.56,
        'polaroid_6016_blue_grey': 5.0,
	},

	'User_4': { 
        'carrera_114S_blue_gray': 3.45,
        'mykita_black': 4.66,
        'polaroid_6016_blue_grey': 3.63,
	},

	'User_5': { 
        'rayban_wayfarer_havane_vert': 1.44,
        'carrera_114S_blue_gray': 5.0,
        'latch_havana_green': 4.5,
	},

	'User_6': {
        'carrera_114S_blue_gray': 3.74,
        'latch_havana_green': 4.54,
        'aliexpress_steampunk_gold_blue_mirror': 3.11,
        'mykita_black': 2.92, 
        'polaroid_6016_blue_grey': 4.55,  
	},

	'User_7': { 
        'rayban_wayfarer_havane_vert': 2.44,
        'carrera_114S_blue_gray': 1.1,
        'aliexpress_steampunk_gold_blue_mirror': 1.2,
        'mykita_black': 4.04,
        'polaroid_6016_blue_grey': 4.44, 
	},

	'User_8': { 
        'rayban_wayfarer_havane_vert': 2.44,
        'latch_havana_green': 4.67,
        'aliexpress_steampunk_gold_blue_mirror': 4.29,
        'mykita_black': 5.0,
	},

	'User_9': { 
        'rayban_wayfarer_havane_vert': 5.0, 
        'carrera_114S_blue_gray': 4.55,
        'latch_havana_green': 4.44,
        'aliexpress_steampunk_gold_blue_mirror': 4.44,
        'mykita_black': 3.44,
        'polaroid_6016_blue_grey': 2.43,
	},

	'User_10': { 
        'rayban_wayfarer_havane_vert': 1.53,
        'carrera_114S_blue_gray': 3.44,
        'latch_havana_green': 3.44,
        'aliexpress_steampunk_gold_blue_mirror': 2.33,
        'mykita_black': 3.44,
        'polaroid_6016_blue_grey': 2.44,
	},

	'User_11': { 
        'rayban_wayfarer_havane_vert': 4.55,
        'carrera_114S_blue_gray': 5.0,
        'latch_havana_green': 1.42,
        'mykita_black': 3.44,
        'polaroid_6016_blue_grey': 3.55,
	},

	'User_12': { 
        'rayban_wayfarer_havane_vert': 3.44,
        'carrera_114S_blue_gray': 2.45,
        'latch_havana_green': 2.55,
        'aliexpress_steampunk_gold_blue_mirror': 4.95,
        'polaroid_6016_blue_grey': 3.55,
	},

	'User_13': { 
        'rayban_wayfarer_havane_vert': 3.66,
        'carrera_114S_blue_gray': 5.0,
        'latch_havana_green': 4.55,
        'aliexpress_steampunk_gold_blue_mirror': 2.44,
        'mykita_black': 1.43,
        'polaroid_6016_blue_grey': 3.44,
	},

	'User_14': { 
        'rayban_wayfarer_havane_vert': 1.24,
        'carrera_114S_blue_gray': 4.14,
        'latch_havana_green': 5.64,
        'aliexpress_steampunk_gold_blue_mirror': 5.0,
        'mykita_black': 1.75,
	},
}
