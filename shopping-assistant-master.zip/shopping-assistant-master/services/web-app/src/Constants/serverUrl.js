const serverUrl = 'http://localhost:8000/';
export default serverUrl;
